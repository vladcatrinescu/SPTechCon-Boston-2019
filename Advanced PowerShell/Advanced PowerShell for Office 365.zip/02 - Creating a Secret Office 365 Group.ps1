New-UnifiedGroup -DisplayName "SPFestSeattle2019-ReorgPrivate" `
	-Alias "O365Group-SPFestSeattle2019-ReorgPrivate" `
	-EmailAddresses "SPFestSeattle2019-ReorgPrivate@globomantics.org" `
	-AccessType Private `
	-HiddenGroupMembershipEnabled

Set-UnifiedGroup -Identity "O365Group-SPFestSeattle2019-ReorgPrivate" -HiddenFromAddressListsEnabled $true
